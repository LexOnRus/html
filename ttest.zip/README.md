phaser-pong
===========

Phaser Pong game example.

Created with Phaser framework by Richard Davey: https://github.com/photonstorm/phaser